![poster](poster.png)

# Hangman
Klassiska hänga gubbe med HTML, CSS och JS.

## Instruktioner
Du ska bygga det klassiska spelet **hangman** ( el. hänga gubbe på sve ). Använd ```hangman.svg```.

![screen](screen.png)